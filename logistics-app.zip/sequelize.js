import OTP_Model from "./models/OTP.js";

const OTP = OTP_Model();

export { OTP };
