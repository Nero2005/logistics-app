const paymentCtrl = {
  pay: async (req, res) => {},
};

export default paymentCtrl;
